
IMPORTANT: PLEASE READ THE CONTENT BELOW BEFORE IMPORTING THE DEMO CONTENT

Please note that:

* The original demo images won't be imported, as we are not allowed to redistribute these images for copyright reasons. Instead random dummy images will be imported.

* Please note that WordPress doesn't export all the settings and if you import this file to your installation, there may be some differences from the demo such as:
- Menus won't be assigned for the theme and by default all the pages will be added to the menu - to assign the Menu you have to go to Appearance -> Menus -> Manage Locations and select the “Main Menu” option in the “Porcelain Theme Main Menu” field.
- Sidebar/Footer widgets

* The theme is easy to setup, so it will be much easier for you to create your own content from scratch, rather than editing the current content and then deleting all the pages, settings and images uploaded to the server. 
